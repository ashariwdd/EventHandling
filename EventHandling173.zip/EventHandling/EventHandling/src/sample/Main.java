package sample;

public class Main {
    public static void main(String[] args) {
        GUI g = new GUI();
    }
}
