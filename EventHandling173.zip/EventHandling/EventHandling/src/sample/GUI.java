package sample;

import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class GUI extends JFrame implements ActionListener {
    String Nama,Alamat,JenisKelamin,Hobby;
    JScrollPane scroll;
    JRadioButton rd_laki, rd_perempuan;
    JComboBox jc_Hobby;

    JButton cari = new JButton();
    JLabel nama = new JLabel();
    JLabel alamat = new JLabel();
    JLabel jeniskelamin = new JLabel();
    JLabel hobby = new JLabel();
    JButton simpan = new JButton();
    JButton ubah  = new JButton();
    JButton hapus = new JButton();
    JButton baca = new JButton();
    JButton reset = new JButton();
    JTextField txtnama  = new JTextField();
    JTextArea TXTalamat = new JTextArea();
    JTextArea TXTtampil = new JTextArea();

    public GUI(){

        nama.setText("Nama");
        nama.setBounds(10,
                10,
                60,
                30);
        add(nama);
        txtnama.setBounds(110,
                10,
                300,
                30);
        add(txtnama);

        alamat.setText("Alamat");
        alamat.setBounds(10,
                50,
                100,
                30);
        add(alamat);
        TXTalamat.setBounds(110,
                50,
                300,
                200);
        scroll = new JScrollPane(TXTalamat);
        scroll.setBounds(110,
                50,
                300,
                200);
        add(scroll);

        jeniskelamin.setText("Jenis Kelamin");
        jeniskelamin.setBounds(10,
                260,
                100,
                30);
        add(jeniskelamin);
        rd_laki = new JRadioButton("Laki-Laki");
        rd_laki.setBounds(110,
                260,
                100,
                30);
        add(rd_laki);
        rd_perempuan = new JRadioButton("Perempuan");
        rd_perempuan.setBounds(220,
                260,
                100,
                30);
        add(rd_perempuan);

        hobby.setText("Hobby");
        hobby.setBounds(10,
                300,
                100,
                30);
        add(hobby);
        String pilih[] = {"Pilihan","Badminton","Yoga","Senam", "Gagal Move on", "Ngeliat dia sama yang lain :("};
        jc_Hobby = new JComboBox(pilih);
        jc_Hobby.setBounds(110,
                300,
                300,
                30);
        add(jc_Hobby);

        simpan.setText("Simpan");
        simpan.setBounds(10,
                340,
                400,
                30);
        simpan.addActionListener(this);
        add(simpan);

        baca.setText("Tampil");
        baca.setBounds(10,
                380,
                400,
                30);
        baca.addActionListener(this);
        add(baca);

        setLayout(null);
        setTitle("Mahasiswa");
        setSize(437,
                460);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
    }

    public void BuatFile() throws IOException {
        String nameFile = "Simpan.txt";
        FileOutputStream outFile = new FileOutputStream(nameFile);
        try{
            DataOutputStream outStream = new DataOutputStream(outFile);
            outStream.writeUTF("Nama   : "+Nama);
            outStream.writeUTF("Alamat  : "+Alamat);
            outStream.writeUTF("Jenis Kelamin : "+JenisKelamin);
            outStream.writeUTF("Hobi   : "+Hobby);
            outStream.close();
            JOptionPane.showMessageDialog(this, "Form Tersimpan");
        }catch (IOException e){
            System.err.println("ERROR LUR : "+e.getMessage() + "\n");
        }
    }

    public void BacaFile() throws IOException{
        String nameFile = "Simpan.txt";
        String nama;
        String alamat;
        String jkelamin;
        String hobi;
        String isi;

        try{
            FileInputStream inFile      = new FileInputStream(nameFile);
            DataInputStream inStream    = new DataInputStream(inFile);
            nama        = inStream.readUTF();
            alamat      = inStream.readUTF();
            jkelamin    = inStream.readUTF();
            hobi        = inStream.readUTF();
            isi = nama +"\n"+ alamat +"\n"+ hobi +"\n"+ jkelamin;
            inStream.close();
            System.out.println(isi);
        }catch (FileNotFoundException e){
            System.err.println("File "+nameFile +" 404 \n");
        }catch (IOException ex ){
            System.err.println("ERROR LUR : "+ex.getMessage() + "\n");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e)  {
        if(e.getActionCommand().equals("Simpan")){
            Nama = txtnama.getText();
            Alamat = TXTalamat.getText();
            if(rd_laki.isSelected()){
                JenisKelamin = "Pria";
            }else{
                JenisKelamin = "Wanita";
            }
            Hobby = (String) jc_Hobby.getSelectedItem();
            try {
                BuatFile();
            } catch (IOException ex) {}

        }else if(e.getActionCommand().equals("Tampil")){
            try {
                BacaFile();
            } catch (IOException ex) {}
        }else{
            dispose();
        }
    }
}

